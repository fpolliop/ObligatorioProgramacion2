﻿
namespace Entities
{
    public enum Role
    {
        Monster, Survivor
    }
}
