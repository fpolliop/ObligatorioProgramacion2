﻿
namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            Client client = new Client();
            client.StartClient();
        }
    }
}
