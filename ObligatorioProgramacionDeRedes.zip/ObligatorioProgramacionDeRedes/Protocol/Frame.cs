﻿using Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Protocol
{
    public class Frame
    {
        private const char FRAME_SEPARATOR = '|';
        private const char DATA_SEPARATOR = '#';

        public ActionType Action { get; set; }
        public string Data { get; set; }
        public int DataLength { get; set; }

        private const int ACTION_POSITION = 0;
        private const int DATA_LENGTH_POSITION = 1;
        private const int DATA_POSITION = 2;

        private const int NICKNAME_POSITION = 0;
        private const int ROLE_POSITION = 1;

        public enum ActionType
        {
            ConnectToServer = 0,
            ListConnectedUsers = 1,
            ListRegisteredUsers = 2,
            JoinMatch = 3,
            Exit = 4,
            MovePlayer = 5,
            AttackPlayer = 6,
        }

        public Frame()
        {

        }

        public Frame(ActionType action, string data)
        {
            Action = action;
            Data = data;
            DataLength = data.Length;
        }

        public Frame(ActionType action, string nickName, int role)
        {
            Action = action;
            StringBuilder builder = new StringBuilder();
            builder.Append(nickName);
            builder.Append(DATA_SEPARATOR);
            builder.Append(role);
            Data = builder.ToString();
            DataLength = Data.Length;
        }

        public Frame(byte[] dataReceived)
        {
            string dataString = Encoding.ASCII.GetString(dataReceived);
            string[] dataStringArray = dataString.Split(FRAME_SEPARATOR);
            Enum.TryParse(dataStringArray[ACTION_POSITION], out ActionType receivedAction);
            this.Action = receivedAction;
            this.DataLength = int.Parse(dataStringArray[DATA_LENGTH_POSITION]);
            this.Data = dataStringArray[DATA_POSITION];

        }

        public string GetUserNickname()
        {
            string[] dataArray = this.Data.Split(DATA_SEPARATOR);
            return dataArray[NICKNAME_POSITION];
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append(this.Action);
            builder.Append(FRAME_SEPARATOR);
            builder.Append(this.DataLength);
            builder.Append(FRAME_SEPARATOR);
            builder.Append(this.Data);

            return builder.ToString();
        }

        public Role GetUserRole()
        {
            Enum.TryParse(this.Data.Split(DATA_SEPARATOR)[ROLE_POSITION], out Role playerRole);
            return playerRole;

        }

        public PlayerGameAction GetPlayerGameAction()
        {
            Enum.TryParse(this.Data.Split(DATA_SEPARATOR)[ROLE_POSITION], out PlayerGameAction playerGameAction);
            return playerGameAction;
        }
    }
}
